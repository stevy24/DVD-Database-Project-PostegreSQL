/*
Query 10 (Window  LAG)
Let's write a query that returns the revenue of the day and the revenue of the
previous day.
Afterwards let's calculate also the percentage growth compared to the previous
day.

*/

select
sum(amount),
date(payment_date) as day,
lag(sum(amount)) over (order by date(payment_date)) as previous_day,
sum(amount) - lag(sum(amount)) over (order by date(payment_date)) as difference,
round((sum(amount) - lag(sum(amount)) over (order by date(payment_date)))
/
lag(sum(amount)) over (order by date(payment_date)) *100,2) as percentage_growth
from payment
group by date(payment_date)