
/*
Query 6: (EXTRACT + Uncorrelated subquery)

Let's create a query that shows 
average daily revenue of all Sundays.
What is the daily average revenue of all Sundays?
*/ss
SELECT 
AVG(total)
FROM 
	(SELECT
	 SUM(amount) as total,
	 DATE(payment_date),
	 EXTRACT(dow from payment_date) as weekday
	 FROM payment
	 WHERE EXTRACT(dow from payment_date)=0
	 GROUP BY DATE(payment_date),weekday) daily




