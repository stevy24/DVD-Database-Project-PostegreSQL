
/*
Query 5: (Uncorrelated subquery)

Let's create a list with the average of
the sales amount each staff_id per customer.
And let's see which staff_idvmakes on average
more revenue per customer?
*/

SELECT 
staff_id,
ROUND(AVG(total),2) as avg_amount 
FROM (
SELECT SUM(amount) as total,customer_id,staff_id
FROM payment
GROUP BY customer_id, staff_id) a
GROUP BY staff_id





