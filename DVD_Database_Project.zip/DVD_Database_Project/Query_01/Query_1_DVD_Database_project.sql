/* Query 2 : CASE + GROUP BY

Let's write a query that gives 
an overview of how many films 
have replacements costs in 
the following cost ranges

1. low: 9.99 - 19.99

2. medium: 20.00 - 24.99

3. high: 25.00 - 29.99

*/

SELECT 
CASE
WHEN replacement_cost BETWEEN 9.99 AND 19.99 THEN 'low'
WHEN replacement_cost BETWEEN 20 AND 24.99 THEN 'medium'
ELSE 'high'
END as cost_range,
COUNT(*)
FROM film
GROUP BY cost_range

