
/*
Query 3: (LEFT JOIN)
Let's create a list of the film titles 
including their title, length,and category name ordered 
descendingly by length.Filter the results to only
the movies in the category 'Drama' or 'Sports'. Let's find out
in wich category is the longest film and how long
is it?

*/

SELECT 
title,
name,
length
FROM film f
LEFT JOIN film_category fc
ON f.film_id=fc.film_id
LEFT JOIN category c
ON c.category_id=fc.category_id
WHERE name = 'Sports' OR name = 'Drama'
ORDER BY length DESC