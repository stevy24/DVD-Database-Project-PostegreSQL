/*
Query 7 : (Window)
Let's return the list of movies including 
film_id, title, length, category, average length of movies
in that category.
*/


SELECT
f.film_id,
title,
name AS category,
length AS length_of_movie,
ROUND(AVG(length) OVER(PARTITION BY name),2) AS avg_length_in_category
FROM film f
LEFT JOIN film_category fc
ON f.film_id = fc.film_id
LEFT JOIN category c
ON fc.category_id = c.category_id
ORDER BY 1




