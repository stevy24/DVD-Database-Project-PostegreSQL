/*
Query 8 : (WILD CARD)

Let's find out how many movies are there that contain 'Saga'
in the description and where the title starts
either with 'A' or ends with 'R'?
Use the alias 'no_of_movies'.

*/

SELECT
COUNT
(*) AS number_of_movie
FROM
film
WHERE
description LIKE '%
AND
(title LIKE '
OR
title LIKE '%R'

