/*
Query 9 : (FILTERING , BETWEEN AND)

Let's find out how many How many payments are there where the amount
is either 0 or between 3.99 and 7.99 and in the
same time have happened on 2020 05 01.

*/

SELECT
COUNT(*)
FROM payment
WHERE(amount = 0 OR amount BETWEEN 3.99 AND 7.99)
AND
payment_date BETWEEN '2020 05 01' AND '2020 05 02'
