/*
Query 10 (RANK):
Lets' whrite a query that returns the customer's name,
the country and how  many payment they have.
*/
SELECT*FROM
(
SELECT 
name,
country,
COUNT(*),
RANK() OVER(PARTITION BY country ORDER BY COUNT(*) DESC) AS rank
FROM customer_list
LEFT JOIN payment
ON id = customer_id
GROUP BY name, country
) AS a
WHERE rank BETWEEN 1 AND 3